from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for
)
from werkzeug.exceptions import abort

from flaskr.auth import login_required
from flaskr.db import get_db

bp = Blueprint('jokes', __name__)

@bp.route('/')
@login_required
def takeAJoke():
    db = get_db()
    jokes = db.execute(
        'SELECT j.id, title, body, created, author_id, nickname, ratings, numberOfRatings'
        ' FROM jokes j JOIN user u ON j.author_id = u.id'
        ' ORDER BY created DESC'
    ).fetchall()
    return render_template('jokes/takeAJoke.html', jokes=jokes)

@bp.route('/myjokes', methods=('GET', 'POST'))
@login_required
def myjokes():
    db = get_db()
    jokes = db.execute(
        'SELECT j.id, title, body, created, author_id, nickname, ratings, numberOfRatings'
        ' FROM jokes j JOIN user u ON j.author_id = u.id'
        ' WHERE ? = j.author_id'
        ' ORDER BY created DESC', 
        (g.user['id'],)
    ).fetchall()
    return render_template('jokes/myjokes.html', jokes=jokes)
"""
This one is actually the leaveAJoke page, but by the time I figured out the naming conventions
I had already modified the create html and then kept using the name elsewhere so I just kept it
"""
@bp.route('/create', methods=('GET', 'POST'))
@login_required
def create():
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        error = None

        if not title:
            error = 'Title is required.'
        else:
            splitTitle = title.split()
            if len(splitTitle) > 10:
                error = 'Title must be 10 words or less'

        if error is not None:
            flash(error)
        else:
            #Checking to see if the title and author are unique
            db = get_db()
            uniqueJoke = db.execute(
                'SELECT EXISTS(SELECT * FROM jokes WHERE title = ? AND author_id = ?)',
                (title, g.user['id'])
            ).fetchone()[0]
            if uniqueJoke == 0:
                db.execute(
                    'INSERT INTO jokes (author_id, title, body, ratings, numberOfRatings)'
                    ' VALUES (?, ?, ?, ?, ?)',
                    (g.user['id'], title, body, 0, 0)
                )
                db.commit()
                return redirect(url_for('jokes.myjokes'))
            else:
                error = 'You have already written a joke with this title.'
                flash(error)

    return render_template('jokes/create.html')
@bp.route('/viewSingle/<int:id>')
@login_required
def viewSingle(id):
    db = get_db()
    joke = db.execute(
        'SELECT j.id, title, body, created, author_id, nickname, ratings, numberOfRatings, u.id as id'
        ' FROM jokes j JOIN user u ON j.author_id = u.id'
        ' WHERE j.id = ?',
        (id,)
    ).fetchone()

    if joke is None:
        abort(404, f"Joke id {id} doesn't exist.")
    userJokeBalance = db.execute(
        'SELECT jokebalance from user where id = ?', (g.user['id'],)
        ).fetchone()
    jokeViewed = db.execute(
        'SELECT EXISTS(SELECT * FROM jokesViewed WHERE joke_id = ? AND user_id = ?)', (id, g.user['id'],)).fetchone()[0]
    if userJokeBalance['jokebalance'] <= 0:
        if joke['author_id'] == g.user['id']:
            return render_template('jokes/viewSingle.html', joke=joke)
        else:
            if jokeViewed == 0:
                error = 'You have a jokebalance of 0 and need to first author a joke and you have not previously viewed that joke.'
                flash(error)
                return redirect(url_for('jokes.myjokes'))
            else:
                return render_template('jokes/viewSingle.html', joke=joke)

    if joke['author_id'] != g.user['id']:
        if jokeViewed == 0:
            db.execute(
            'INSERT INTO jokesViewed(user_id, joke_id, has_rated) VALUES (?, ?, 0)',
            (g.user['id'], id)
            )
            db.commit()
            db.execute(
            'UPDATE user SET jokebalance = jokebalance - 1 WHERE id = ?',
            (g.user['id'],)
            )
            db.commit()
        

    return render_template('jokes/viewSingle.html', joke=joke)

def get_post(id):
    #This is to get the joke that another author created, to only be able to view and rate it
    joke = get_db().execute(
        'SELECT j.id, title, body, created, author_id, nickname, u.id'
        ' FROM jokes j JOIN user u ON j.author_id = u.id'
        ' WHERE j.id = ?',
        (id,)
    ).fetchone()

    if joke is None:
        abort(404, f"Post id {id} doesn't exist.")


    return joke

@bp.route('/<int:id>/update', methods=('GET', 'POST'))
@login_required
def update(id):
    joke = get_post(id)

    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        error = None

        if not title:
            error = 'Title is required.'

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                'UPDATE jokes SET body = ?'
                ' WHERE id = ?',
                (body, id)
            )
            db.commit()
            return redirect(url_for('jokes.takeAJoke'))

    return render_template('jokes/update.html', joke=joke)

@bp.route('/<int:id>/delete', methods=('POST',))
@login_required
def delete(id):
    get_post(id)
    db = get_db()
    deletingEntries = db.execute(
        'select joke_id from jokesViewed where joke_id = ?', (id,)
    ).fetchall()
    for entry in deletingEntries:
        db.execute('DELETE FROM jokesViewed WHERE joke_id = ?', (entry['joke_id'],))
        db.commit()

    userID = db.execute('SELECT author_id from jokes where id=?', (id,)).fetchone()
    db.execute('DELETE FROM jokes WHERE id = ?', (id,))
    if g.user['jokebalance'] != 0: #Change to make it so deleting doesn't take you to negative joke balance, but it will decrement you
        db.execute('UPDATE user SET jokebalance = jokebalance - 1 WHERE id = ?', (userID['author_id'],))
    db.commit()
    return redirect(url_for('jokes.takeAJoke'))


@bp.route('/viewSingle/<int:joke_id>', methods=['POST',])
def rate_joke(joke_id):
    rating = int(request.form['rating'])

    #Validate that the rating is between 1 and 10
    if not (1 <= rating <= 10):
        flash("Rating must be between 1 and 10.")
        return redirect(url_for('jokes.viewSingle', id=joke_id))
    
    db = get_db()#Validating that a joke cannot be rated more than once.
    jokeRated = db.execute(
        'SELECT has_rated from jokesViewed where user_id = ? AND joke_id = ?', (g.user['id'], joke_id)
    ).fetchone()
    if jokeRated['has_rated'] != 0:
        flash("Error. You have already rated this joke")
    else:
        db.execute(
            'UPDATE jokes SET ratings = ratings + ?, numberOfRatings = numberOfRatings + 1 WHERE id = ?',
            (rating, joke_id)
        )
        db.execute(
            'UPDATE jokesViewed SET has_rated = 1 WHERE joke_id = ? AND user_id = ?', (joke_id, g.user['id'])
        )
        db.commit()
        flash("Successfully rated joke.")

    return redirect(url_for('jokes.viewSingle', id=joke_id))

"""
This function was used for testing purposes to make sure data was actually
being inputted correctly
"""
"""
@bp.route('/print-data')
def print_data():
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM jokesViewed') 
    rows = cursor.fetchall()
    db.close()
    
    for row in rows:
        print(dict(row)) 

    return "Data printed to console."
"""